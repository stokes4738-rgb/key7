# Key7: No-Mac build and installation on iPhone 7 Plus

This guide is for **iPhone 7 Plus, iOS 15.8.8, Dopamine rootless**. No personal Mac or Apple developer certificate is required. **You do need internet access and a GitHub account for the cloud build.** It is **not** an app binary yet. GitHub will compile the Swift source using a hosted macOS/Xcode machine and create downloadable installers. This build has not been run or tested on your phone.

## What the automated build produces

- `org.key7.fido-lab_0.1.0_iphoneos-arm64.deb`: rootless package for Sileo (the intended primary install method on Dopamine). It installs the app to `/var/jb/Applications/Key7.app`, uses `ldid` to fake-sign the executable after installation, and calls `uicache` for the icon.
- `Key7-0.1.0-TrollStore.ipa`: optional app installer for devices with TrollStore already installed. You don't need it if the `.deb` works.

These install the **experimental BLE FIDO2 research app**, **not** a FIDO-certified external hardware security key. Many browsers and OSes won't accept BLE CTAP as a hardware security key, and Apple Account hardware security key pairing is not supported.

## Step 1: Prepare the project on the 7 Plus

1. Download the `Key7FIDO-BLE-NoMac.zip` file from this chat, open it using Files or Filza, and extract the full directory. Make sure the hidden `.github` folder comes along.
2. Create a new **empty** repository at <https://github.com/new>. Call it `key7`. Do not check the README or .gitignore boxes, since they are in the downloaded project already.
3. Install `git` from Sileo if NewTerm doesn't already have it (use `git --version` to test). Use Filza to move the extracted `Key7FIDO-BLE` folder to `/var/mobile/Key7FIDO-BLE`. This only changes your own downloaded project files, not the system or jailbreak.
4. Open NewTerm and enter:

```sh
cd /var/mobile/Key7FIDO-BLE
sh Tools/publish_github.sh https://github.com/YOUR_USERNAME/key7.git
```

Replace `YOUR_USERNAME` with your own. On GitHub HTTPS authentication, the password prompt needs a GitHub Personal Access Token with permission to push to that repo, **not** your GitHub password. If your account has enforced token policies, select appropriate fine-grained repository contents permissions and workflow permission. Don't paste your token into chat or embed it in the command line. Do not use a public repo for personal secrets (this project contains no credentials).

> Alternative: Upload the source folder to an existing GitHub repository by any Git-capable app or tool, preserving `.github/workflows/build-no-mac.yml`. The script is just a convenience to avoid uploading each file by hand.

## Step 2: Build using GitHub's Mac (from Safari)

1. Open your GitHub repository > **Actions**.
2. Select **Build Key7 for Jailbroken iPhone 7 Plus**.
3. If necessary, enable Actions for the repo. Click **Run workflow**, choose `main`, and run it. A push to `main` also triggers the build.
4. Open the completed run. Under **Artifacts**, download **Key7-iOS15-jailbroken-installers**. It contains the `.deb` and `.ipa` files.
5. If the build fails, inspect the failed step and share the actual error text. The source is experimental and may require build corrections.

GitHub hosted runners may count against your GitHub Actions allowance. Review GitHub's current Actions usage and pricing for your account.

## Step 3: Install on Dopamine without a Mac

**Option A: Sileo (recommended).** Extract the downloaded Actions artifact ZIP. Use Files/Filza to open `org.key7.fido-lab_0.1.0_iphoneos-arm64.deb` in Sileo, then install. If Sileo reports `ldid` or a rootless dependency missing, use the real dependency from your configured repositories. After installation, check your Home Screen for Key7. If no icon appears, in NewTerm run `uicache -a`. If Sileo refuses the file, capture the exact error rather than forcing a package architecture change.

**Option B: TrollStore.** If TrollStore is already installed and working, import `Key7-0.1.0-TrollStore.ipa` and install. Avoid installing both variants simultaneously.

## Step 4: First safe tests

1. On the iPhone, turn on Bluetooth, set up Touch ID/passcode, and open **Key7**.
2. Select **Start key**, grant the Bluetooth permission, and leave the app foregrounded and unlocked.
3. On a separate machine or supported BLE GATT client, look for `Key7-FIDO-Lab`, service `0xFFFD`, and verify subscription and round-trip PING. BLE pairing and host compatibility are still unverified.
4. Only use dummy/local test credentials. Do not use this as the sole security key for your real accounts.

## Troubleshooting

- **No Git / permission denied pushing:** Ensure your repo exists, Git is installed, and your GitHub token has appropriate repository permissions. Never put the token in screenshots.
- **Actions workflow missing:** Verify `.github/workflows/build-no-mac.yml` was included when the project folder was extracted.
- **Build failed:** The workflow prints the last 180 lines of the Xcode build log so compiler errors are visible. No successful build has been verified yet.
- **Installed but crashes:** Check `ldid -S /var/jb/Applications/Key7.app/Key7` and `uicache -a` (if these programs are available). Restart the app and check for crash logs. A binary built but unable to start needs debugging.
- **Bluetooth discovered but sign-in fails:** This is a research limitation, not an installation failure. Modern WebAuthn clients may require a different transport and a FIDO-certified hardware key.
