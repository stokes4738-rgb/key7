#!/usr/bin/env python3
"""Lab-only makeCredential -> getAssertion -> ECDSA verification.
Needs `pip install bleak cryptography`. Uses only an invalid test RP ID.
Do NOT use this experimental app with any real account.
"""
import asyncio
import hashlib
import os
import sys
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from ble_probe import CTRL, STATUS, LENGTH, REV, Receiver, frame_message


def head(major, num):
    h = major << 5
    if num < 24: return bytes([h | num])
    if num < 256: return bytes([h | 24, num])
    if num < 65536: return bytes([h | 25]) + num.to_bytes(2, "big")
    if num < 2**32: return bytes([h | 26]) + num.to_bytes(4, "big")
    return bytes([h | 27]) + num.to_bytes(8, "big")


def enc(x):
    if x is True: return b"\xf5"
    if x is False: return b"\xf4"
    if x is None: return b"\xf6"
    if isinstance(x, int): return head(0, x) if x >= 0 else head(1, -1-x)
    if isinstance(x, bytes): return head(2, len(x)) + x
    if isinstance(x, str):
        raw = x.encode()
        return head(3, len(raw)) + raw
    if isinstance(x, list): return head(4, len(x)) + b"".join(enc(i) for i in x)
    if isinstance(x, dict):
        pairs = sorted([(enc(k), enc(v)) for k, v in x.items()], key=lambda kv: (len(kv[0]), kv[0]))
        return head(5, len(pairs)) + b"".join(k + v for k, v in pairs)
    raise TypeError(type(x))


def dec(raw, start=0, depth=0):
    if depth > 16: raise ValueError("excessive CBOR nesting")
    if start >= len(raw): raise ValueError("truncated CBOR")
    initial = raw[start]
    major, ai = initial >> 5, initial & 31
    pos = start + 1
    if major == 7:
        if ai == 20: return False, pos
        if ai == 21: return True, pos
        if ai == 22: return None, pos
        raise ValueError("unsupported simple CBOR")
    if ai < 24: length = ai
    elif ai in (24,25,26,27):
        size = {24:1,25:2,26:4,27:8}[ai]
        if len(raw) < pos+size: raise ValueError("truncated length")
        length = int.from_bytes(raw[pos:pos+size], "big")
        pos += size
    else: raise ValueError("indefinite CBOR not supported")
    if major == 0: return length, pos
    if major == 1: return -1-length, pos
    if major in (2,3):
        end = pos + length
        if end > len(raw): raise ValueError("truncated data")
        block = raw[pos:end]
        return (block if major == 2 else block.decode()), end
    if major == 4:
        out = []
        for _ in range(length):
            value, pos = dec(raw,pos,depth+1)
            out.append(value)
        return out,pos
    if major == 5:
        out = {}
        for _ in range(length):
            key, pos = dec(raw,pos,depth+1)
            value,pos = dec(raw,pos,depth+1)
            out[key] = value
        return out,pos
    raise ValueError("unsupported CBOR type")


async def main():
    from bleak import BleakScanner, BleakClient
    rp = "key7-lab.invalid"  # .invalid reserved, never an active online account
    print("Local test: ", rp)
    devices = await BleakScanner.discover(timeout=12)
    device = next((d for d in devices if "Key7" in (d.name or "")), None)
    if device is None: raise RuntimeError("Key7 not found. Keep the 7 Plus screen open and Start key enabled.")
    queue = asyncio.Queue()
    rx = Receiver()

    def on_status(_sender, packet):
        result = rx.accept(bytes(packet))
        if result is not None: queue.put_nowait(result)

    async with BleakClient(device, timeout=25) as client:
        await client.write_gatt_char(REV, b"\x20", response=True)
        length = int.from_bytes(await client.read_gatt_char(LENGTH), "big")
        await client.start_notify(STATUS, on_status)

        async def ctap(command, params):
            payload = bytes([command]) + (enc(params) if params is not None else b"")
            for frame in frame_message(0x83, payload, chunk=min(20, length)):
                await client.write_gatt_char(CTRL, frame, response=True)
            while True:
                wrapper, response = await asyncio.wait_for(queue.get(), timeout=60)
                if wrapper == 0x82:
                    print("Touch ID/passcode approval needed…")
                    continue
                if wrapper != 0x83: raise RuntimeError(f"BLE transport 0x{wrapper:02x}: {response.hex()}")
                if not response: raise RuntimeError("Empty CTAP reply")
                if response[0] != 0: raise RuntimeError(f"CTAP error 0x{response[0]:02x}")
                answer, consumed = dec(response[1:])
                if consumed != len(response) - 1: raise RuntimeError("Invalid CBOR remainder")
                return answer

        info = await ctap(4, None)
        print("getInfo versions:", info[1])
        create_hash = hashlib.sha256(os.urandom(32)).digest()
        print("Approve the test account creation on the 7 Plus.")
        made = await ctap(1, {
            1: create_hash,
            2: {"id": rp, "name": "Key7 local test"},
            3: {"id": b"local-test-user", "name": "test", "displayName": "Test User"},
            4: [{"type": "public-key", "alg": -7}],
            7: {"rk": False, "uv": True}
        })
        if made[1] != "none": raise RuntimeError("Unexpected attestation format")
        auth = made[2]
        rp_hash = hashlib.sha256(rp.encode()).digest()
        if auth[:32] != rp_hash or auth[32] & 0x45 != 0x45: raise RuntimeError("Invalid register authData")
        id_len = int.from_bytes(auth[53:55], "big")
        credential_id = auth[55:55+id_len]
        cose, consumed = dec(auth[55+id_len:])
        if consumed != len(auth) - 55 - id_len: raise RuntimeError("Incomplete credential key")
        if cose[1] != 2 or cose[3] != -7 or cose[-1] != 1: raise RuntimeError("Unsupported COSE key")
        public_key = ec.EllipticCurvePublicNumbers(int.from_bytes(cose[-2],"big"),
                                                    int.from_bytes(cose[-3],"big"), ec.SECP256R1()).public_key()
        print("Registered a local test credential:", credential_id.hex()[:16], "...")
        challenge = hashlib.sha256(os.urandom(32)).digest()
        print("Approve the test sign-in on the 7 Plus.")
        assertion = await ctap(2, {
            1: rp, 2: challenge,
            3: [{"type": "public-key", "id": credential_id}],
            5: {"uv": True, "up": True}
        })
        if assertion[1]["id"] != credential_id: raise RuntimeError("Wrong key returned")
        if assertion[2][:32] != rp_hash or assertion[2][32] & 0x05 != 0x05:
            raise RuntimeError("Invalid assertion flags or RP binding")
        public_key.verify(assertion[3], assertion[2] + challenge, ec.ECDSA(hashes.SHA256()))
        print("PASS: registration, authentication, RP-bound ECDSA signature verified.")
        print("This is a lab crypto/transport success, NOT proof of browser/website compatibility.")
        await client.stop_notify(STATUS)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except Exception as exc:
        print("FAIL:", type(exc).__name__, str(exc))
        sys.exit(1)
