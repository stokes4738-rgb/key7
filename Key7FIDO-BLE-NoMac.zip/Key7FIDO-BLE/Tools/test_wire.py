#!/usr/bin/env python3
"""Offline regression checks for the Python BLE test-client framing. Not an iOS compile test."""
import unittest
from ble_probe import frame_message, Receiver


class FramingTests(unittest.TestCase):
    def test_40_byte_ping(self):
        payload = bytes(range(40))
        fragments = list(frame_message(0x81, payload))
        self.assertEqual([len(f) for f in fragments], [20, 20, 5])
        self.assertEqual(fragments[0][:3], b"\x81\x00\x28")
        self.assertEqual(fragments[1][:1], b"\x00")
        self.assertEqual(fragments[2][:1], b"\x01")
        receiver = Receiver()
        completed = [receiver.accept(part) for part in fragments]
        self.assertEqual(completed[-1], (0x81, payload))

    def test_single_packet_get_info(self):
        packets = list(frame_message(0x83, b"\x04"))
        self.assertEqual(packets, [b"\x83\x00\x01\x04"])
        self.assertEqual(Receiver().accept(packets[0]), (0x83, b"\x04"))

    def test_4096_byte_payload(self):
        payload = bytes(i & 255 for i in range(4096))
        receiver = Receiver()
        result = None
        for fragment in frame_message(0x83, payload):
            result = receiver.accept(fragment)
        self.assertEqual(result, (0x83, payload))


if __name__ == "__main__":
    unittest.main()
