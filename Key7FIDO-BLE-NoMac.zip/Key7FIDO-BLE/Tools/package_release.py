#!/usr/bin/env python3
"""Package an already-compiled iOS .app for TrollStore and Dopamine rootless.

Run only on a trusted build host with a real, compiled iOS app bundle.
Uses Python stdlib, including a simple ar writer for dpkg packages.
No ability to compile Swift and no fake executable generation.
"""
from __future__ import annotations
import argparse
import io
from pathlib import Path
import shutil
import stat
import tarfile
import tempfile
import time
import zipfile

PKG = 'org.key7.fido-lab'
VER = '0.1.0'


def ar_member(name: str, payload: bytes) -> bytes:
    label = (name + '/').encode('ascii')
    if len(label) > 16:
        raise ValueError('ar member name too long')
    header = (
        label.ljust(16, b' ') +
        str(int(time.time())).encode().ljust(12, b' ') +
        b'0'.ljust(6, b' ') +
        b'0'.ljust(6, b' ') +
        b'100644'.ljust(8, b' ') +
        str(len(payload)).encode().ljust(10, b' ') +
        b'`\n'
    )
    assert len(header) == 60
    return header + payload + (b'\n' if len(payload) % 2 else b'')


def tar_gz_tree(root: Path) -> bytes:
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz', format=tarfile.GNU_FORMAT) as t:
        for path in sorted(root.rglob('*')):
            t.add(path, arcname='./' + str(path.relative_to(root)), recursive=False)
    return buffer.getvalue()


def build_ipa(app: Path, target: Path):
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(app.rglob('*')):
            if path.is_file():
                z.write(path, arcname='Payload/' + app.name + '/' + str(path.relative_to(app)))


def build_deb(app: Path, target: Path):
    with tempfile.TemporaryDirectory(prefix='key7-package-') as tmp:
        root = Path(tmp)
        control = root / 'control'
        data = root / 'data'
        control.mkdir()
        app_dest = data / 'var/jb/Applications/Key7.app'
        shutil.copytree(app, app_dest, symlinks=True)
        (control / 'control').write_text('''Package: org.key7.fido-lab
Version: 0.1.0
Architecture: iphoneos-arm64
Maintainer: Key7 Research <noreply@example.invalid>
Section: Utilities
Priority: optional
Depends: firmware (>= 15.0), ldid
Description: Experimental iOS 15 Bluetooth FIDO2 authenticator
 Research only. Not a certified hardware security key.
''')
        post = control / 'postinst'
        post.write_text('''#!/bin/sh
set -e
APP=/var/jb/Applications/Key7.app
if command -v ldid >/dev/null 2>&1; then
  ldid -S "$APP/Key7" || true
fi
if command -v uicache >/dev/null 2>&1; then
  uicache -p "$APP" || uicache -a || true
fi
exit 0
''')
        pre = control / 'prerm'
        pre.write_text('''#!/bin/sh
if command -v uicache >/dev/null 2>&1; then
  uicache -u /var/jb/Applications/Key7.app || true
fi
exit 0
''')
        post.chmod(post.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        pre.chmod(pre.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        target.write_bytes(
            b'!<arch>\n' +
            ar_member('debian-binary', b'2.0\n') +
            ar_member('control.tar.gz', tar_gz_tree(control)) +
            ar_member('data.tar.gz', tar_gz_tree(data))
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('app', type=Path)
    parser.add_argument('output_dir', type=Path)
    args = parser.parse_args()
    app = args.app.resolve()
    if not (app.is_dir() and (app / 'Key7').is_file() and (app / 'Info.plist').is_file()):
        parser.error('Expected a compiled Key7.app with a Key7 binary and Info.plist; no source-only packages allowed')
    args.output_dir.mkdir(parents=True, exist_ok=True)
    build_ipa(app, args.output_dir / f'Key7-{VER}-TrollStore.ipa')
    build_deb(app, args.output_dir / f'{PKG}_{VER}_iphoneos-arm64.deb')
    print('Created release installers in', args.output_dir)


if __name__ == '__main__':
    main()
