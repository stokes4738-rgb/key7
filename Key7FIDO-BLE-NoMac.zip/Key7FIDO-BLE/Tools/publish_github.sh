#!/bin/sh
# Run from the project folder in NewTerm on your jailbroken iPhone.
# Prerequisite: git installed and an EMPTY GitHub repo created in Safari.
set -eu
if [ "$#" -ne 1 ]; then
  echo "Usage: sh Tools/publish_github.sh https://github.com/USERNAME/key7.git" >&2
  exit 2
fi
cd "$(dirname "$0")/.."
if ! command -v git >/dev/null 2>&1; then
  echo "git is missing. Install Git from Sileo first." >&2
  exit 1
fi
if [ ! -f .github/workflows/build-no-mac.yml ]; then
  echo "Workflow file not found. Unzip the entire project, including hidden .github folder." >&2
  exit 1
fi
if [ ! -d .git ]; then
  git init
fi
git branch -M main
git add .
if ! git diff --cached --quiet; then
  git -c user.name='Key7 Research' -c user.email='key7@users.noreply.github.com' commit -m 'Add Key7 BLE research project with no-Mac installer builds'
fi
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$1"
else
  git remote add origin "$1"
fi
printf '\nPublishing project. GitHub may prompt for username and a personal access token.\n'
printf 'Do not enter your normal GitHub password as the token.\n'
git push --set-upstream origin main
printf '\nNow open your GitHub repository -> Actions -> Build Key7 for Jailbroken iPhone 7 Plus.\n'
