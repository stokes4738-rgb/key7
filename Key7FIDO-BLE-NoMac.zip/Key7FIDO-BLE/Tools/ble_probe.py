#!/usr/bin/env python3
"""Direct, non-account test for the Key7 experimental FIDO2 BLE service.
Requires: Python 3.9+ and `pip install bleak`. Does not collect credentials.
"""
import asyncio
import sys

SERVICE = "0000fffd-0000-1000-8000-00805f9b34fb"
CTRL = "f1d0fff1-deaa-ecee-b42f-c9ba7ed623bb"
STATUS = "f1d0fff2-deaa-ecee-b42f-c9ba7ed623bb"
LENGTH = "f1d0fff3-deaa-ecee-b42f-c9ba7ed623bb"
REV = "f1d0fff4-deaa-ecee-b42f-c9ba7ed623bb"


def frame_message(cmd, data, chunk=20):
    if len(data) > 65535:
        raise ValueError("frame too long")
    first = bytes([cmd]) + len(data).to_bytes(2, "big") + data[:chunk - 3]
    yield first
    position = chunk - 3
    seq = 0
    while position < len(data):
        part = data[position:position + chunk - 1]
        yield bytes([seq]) + part
        position += len(part)
        seq = (seq + 1) % 128


class Receiver:
    def __init__(self):
        self.cmd = None
        self.length = 0
        self.body = b""
        self.seq = 0

    def accept(self, chunk):
        if not chunk:
            raise ValueError("empty frame")
        if chunk[0] & 128:
            if len(chunk) < 3:
                raise ValueError("short init frame")
            self.cmd = chunk[0]
            self.length = int.from_bytes(chunk[1:3], "big")
            self.body = chunk[3:]
            self.seq = 0
        else:
            if self.cmd is None or chunk[0] != self.seq:
                raise ValueError("invalid continuation")
            self.body += chunk[1:]
            self.seq = (self.seq + 1) % 128
        if len(self.body) > self.length:
            raise ValueError("response exceeds length")
        if len(self.body) == self.length:
            result = (self.cmd, self.body)
            self.__init__()
            return result
        return None


async def probe():
    from bleak import BleakScanner, BleakClient
    print("Scanning for Key7-FIDO-Lab ... Keep the app open on your 7 Plus.")
    devices = await BleakScanner.discover(timeout=12)
    matching = [d for d in devices if "Key7" in (d.name or "")]
    if not matching:
        print("No Key7 advertiser found. If the service UUID is in iOS overflow advertising, try an iOS BLE scanner.")
        print("Seen nearby names:", ", ".join(d.name for d in devices if d.name) or "(none)")
        return 1
    device = matching[0]
    print("Connecting to", device.name, "...", device.address)
    queue = asyncio.Queue()
    rx = Receiver()

    def on_notify(_sender, chunk):
        result = rx.accept(bytes(chunk))
        if result is not None:
            queue.put_nowait(result)

    async with BleakClient(device, timeout=25) as client:
        print("Connected.")
        rev = await client.read_gatt_char(REV)
        print("Revision bitfield:", rev.hex())
        await client.write_gatt_char(REV, bytes([0x20]), response=True)
        max_len = int.from_bytes(await client.read_gatt_char(LENGTH), "big")
        print("Control Point length:", max_len)
        await client.start_notify(STATUS, on_notify)

        async def exchange(command, payload):
            for part in frame_message(command, payload, chunk=min(max_len, 20)):
                await client.write_gatt_char(CTRL, part, response=True)
            while True:
                response_command, response_body = await asyncio.wait_for(queue.get(), 30)
                if response_command == 0x82: # KEEPALIVE
                    print("Keepalive:", response_body.hex())
                    continue
                return response_command, response_body

        ping = bytes(range(40))
        response_cmd, response = await exchange(0x81, ping)
        print("PING:", "PASS" if response_cmd == 0x81 and response == ping else "FAIL")
        response_cmd, response = await exchange(0x83, b"\x04") # CTAP2 getInfo
        print("GetInfo transport command:", hex(response_cmd))
        print("CTAP2 status:", hex(response[0]) if response else "empty")
        print("CBOR response (hex):", response[1:].hex() if response else "")
        if response_cmd != 0x83 or not response or response[0] != 0:
            print("CTAP2 getInfo failed")
            return 1
        print("Transport tests passed. Website/passkey interoperability is NOT proven.")
        await client.stop_notify(STATUS)
        return 0


if __name__ == "__main__":
    try:
        sys.exit(asyncio.run(probe()))
    except Exception as exc:
        print(type(exc).__name__ + ":", exc)
        print("BLE security pairing, platform support, and iPhone advertisement limits may be responsible.")
        sys.exit(2)
