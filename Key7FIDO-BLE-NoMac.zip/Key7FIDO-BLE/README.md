# Key7: iPhone 7 Plus FIDO2/Bluetooth security-key research prototype

**No Mac?** See [NO_MAC_INSTALL.md](NO_MAC_INSTALL.md) for the GitHub Actions cloud build that makes a rootless `.deb` for Sileo and an optional `.ipa` for TrollStore. Do not confuse the ZIP source archive with a precompiled, functioning app.

**Target**: iPhone 7 Plus, iOS 15.8.8. Works in a normal iOS app sandbox; **Dopamine/rootless jailbreak is not required** for this first approach. No private APIs, no downloads at runtime, no third-party Swift packages.

**Status:** Complete source project for a **research prototype**, not a compiled .ipa, certified security key, or tested commercial WebAuthn authenticator. It has **not been compiled on an actual Mac or installed on an iPhone** in this session. **Never register production accounts with it.**

## What's implemented

- CoreBluetooth peripheral serving official FIDO Service UUID `FFFD` and its control/status/length/revision characteristics.
- FIDO BLE initial/continuation-fragment serialization and parsing, 20-byte GATT packet size, `PING` echo, revision selection, BLE keepalives, CTAP2 `authenticatorGetInfo`.
- CTAP2.0 `authenticatorMakeCredential` and `authenticatorGetAssertion` for ES256 (P-256/ECDSA), with non-discoverable credentials only. CBOR codec included.
- On-device approval using Touch ID **or device passcode** (`LocalAuthentication`), and software P-256 private key material in iOS device-only, when-unlocked Keychain storage.
- No app-key uploads and no external network dependency.

## Important limitations

1. **Not a tested security key.** A client must still discover, pair with, and support FIDO2-over-BLE. Many modern FIDO/WebAuthn systems emphasize USB/NFC or phone-as-passkey hybrid (QR + BLE) rather than CTAP-over-BLE. This app **does not implement hybrid transport**, and cannot present itself as an Apple-certified security key.
2. iOS CoreBluetooth cannot freely set arbitrary FIDO BLE advertising flags/service data. Background advertising also changes on iOS. Therefore **foreground app, screen awake** is required for initial tests. Pairing may not work on every host.
3. Bluetooth encryption is requested using CoreBluetooth `writeEncryptionRequired`. The project does not implement custom BLE pairing, MITM-resistant passkey pairing, rate limits, multi-peer isolation, complete cancellation, or security hardening. BLE pairing security must be separately audited and verified. Do **not** trust it for sensitive accounts.
4. No discoverable/resident passkeys, CTAP1/U2F, client PIN, pinUvAuth protocol, hmac-secret, credProtect, credential management, or attestation certification. An account that **requires a discoverable passkey** cannot use this prototype.
5. Credential private keys are Keychain-protected software keys, not Secure Enclave keys. The latter needs extra design and platform testing.
6. Software is not yet built or device-tested. Swift code and Xcode configurations may require minor Xcode-version adjustments.

## Build on a Mac (Xcode)

1. Unzip this archive and open `Key7.xcodeproj` in Xcode 14 or later.
2. Select the **Key7** target, then **Signing & Capabilities**. Choose your Apple developer Personal Team or paid team, and replace `org.key7.FIDOLab` with an unused bundle identifier if needed.
3. Set the deployment target to iOS 15.0 (already configured), choose your connected **iPhone 7 Plus**, and build/run (Product > Run). Trust the developer certificate on the phone if prompted. A free Apple ID may have periodic signing renewal requirements.
4. On iOS, enable Bluetooth and set up a device passcode + Touch ID. Tap **Start key** and allow Bluetooth. Keep Key7 **open and unlocked** while testing.
5. On a nearby Mac/Windows/Linux computer install Python package `bleak`: `python3 -m pip install bleak`. Then run `python3 Tools/ble_probe.py`. The script scans, connects, selects FIDO2, runs a 40-byte PING, and sends `authenticatorGetInfo`.

**No Mac/Xcode?** The included GitHub Actions workflow runs Xcode on GitHub-hosted macOS, compiles the app, and packages an `iphoneos-arm64` rootless `.deb` and an optional `.ipa`. You need a GitHub account and internet, but no Mac of your own. See [NO_MAC_INSTALL.md](NO_MAC_INSTALL.md). A jailbreak changes installation options; it does not remove the compilation step.

## Offline tests

- `python3 Tools/test_wire.py` runs offline test-client framing checks (no third-party dependencies).
- Optional end-to-end cryptographic lab test: run `python3 -m pip install bleak cryptography` and then `python3 Tools/ctap_full_test.py`. It creates a dummy `.invalid` credential and checks a signed login locally. It has **not been run on the iPhone yet**.
- Use a generic Bluetooth LE GATT scanner if the test script cannot find the phone. Look for service `0xFFFD` and verify characteristics `F1D0FFF1` through `F1D0FFF4`.
- Passing `PING` and `getInfo` proves the Bluetooth + CTAP transport path works. It **does not** prove an OS or website will accept the phone as a security key.

## Next interoperability steps

1. Verify GATT characteristic visibility and pairing/encryption on the specific host.
2. Write a local CTAP2 test harness for `makeCredential`/`getAssertion` using randomly generated test RP IDs and hashes, and verify returned signatures using the COSE public key.
3. Investigate the OS/browser's FIDO BLE transport support; if absent, a transport bridge or different architecture is needed.
4. Audit cancellation, concurrent requests, key storage, hardware-backed cryptography, pairing methods and FIDO conformance **before** attempting real accounts.

## References

- FIDO CTAP 2.3, §11.4 Bluetooth LE transport: https://fidoalliance.org/specs/fido-v2.3-ps-20260226/fido-client-to-authenticator-protocol-v2.3-ps-20260226.html
- Apple CoreBluetooth peripheral advertising: https://developer.apple.com/documentation/corebluetooth/cbperipheralmanager/startadvertising%28_%3A%29
- Apple background BLE behavior: https://developer.apple.com/library/archive/documentation/NetworkingInternetWeb/Conceptual/CoreBluetooth_concepts/CoreBluetoothBackgroundProcessingForIOSApps/PerformingTasksWhileYourAppIsInTheBackground.html
